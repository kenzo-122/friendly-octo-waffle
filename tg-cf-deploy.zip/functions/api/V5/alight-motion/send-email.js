// ============================================
// CLOUDFLARE PAGES FUNCTIONS
// ENDPOINT: /api/v5/alight-motion/send-email
// ============================================

// Simulasi database dengan Map (akan hilang jika restart)
const userData = new Map();

function generateToken() {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
}

export async function onRequest(context) {
    const { request } = context;
    const url = new URL(request.url);
    const email = url.searchParams.get('email');

    // CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
        return new Response(null, { headers });
    }

    // Validasi email
    if (!email) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Parameter email wajib diisi',
            data: null
        }), { status: 400, headers });
    }

    // Generate token
    const token = generateToken();
    const verificationLink = `https://xyrooo.com/verify?token=${token}`;

    // Simpan data
    if (!userData.has(email)) {
        userData.set(email, {
            email: email,
            type: 'New Member',
            usage: '1/5',
            isVerified: false,
            verificationLink: verificationLink
        });
    } else {
        const data = userData.get(email);
        data.verificationLink = verificationLink;
        data.usage = '1/5';
        userData.set(email, data);
    }

    // Response sukses
    const response = {
        success: true,
        message: 'Link verifikasi berhasil dikirim.',
        data: {
            email: email,
            type: userData.get(email).type,
            usage: userData.get(email).usage,
            instruksi: 'Cek kotak masuk atau spam email Anda. Salin link verifikasi yang diterima dari Alight Motion dan gunakan pada endpoint /verif.',
            verification_link: verificationLink
        }
    };

    return new Response(JSON.stringify(response), { headers });
}