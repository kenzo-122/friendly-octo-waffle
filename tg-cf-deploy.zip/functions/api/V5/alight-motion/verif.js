// ============================================
// CLOUDFLARE PAGES FUNCTIONS
// ENDPOINT: /api/v5/alight-motion/verif
// ============================================

// Gunakan data yang sama dengan send-email
// Dalam production, gunakan KV storage
const userData = new Map();

export async function onRequest(context) {
    const { request } = context;
    const url = new URL(request.url);
    const email = url.searchParams.get('email');
    const token = url.searchParams.get('token');

    // CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
        return new Response(null, { headers });
    }

    // Validasi email
    if (!email) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Parameter email wajib diisi',
            data: null
        }), { status: 400, headers });
    }

    // Validasi token
    if (!token) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Parameter token wajib diisi',
            data: null
        }), { status: 400, headers });
    }

    // Cek apakah email terdaftar
    if (!userData.has(email)) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Email tidak ditemukan. Silakan kirim email terlebih dahulu.',
            data: null
        }), { status: 404, headers });
    }

    // Validasi token
    if (token.length < 3) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Token verifikasi tidak valid.',
            data: null
        }), { status: 400, headers });
    }

    // Upgrade ke premium
    const data = userData.get(email);
    data.type = 'Premium Member';
    data.isVerified = true;
    data.usage = '2/5';
    data.duration = '1 Year';
    userData.set(email, data);

    // Response sukses
    const response = {
        success: true,
        message: 'Verifikasi berhasil!',
        data: {
            email: email,
            type: data.type,
            duration: data.duration,
            usage: data.usage,
            instruksi: 'Akun Anda sekarang sudah berstatus Premium. Silakan login ke aplikasi Alight Motion menggunakan email tersebut atau refresh jika sudah login.'
        }
    };

    return new Response(JSON.stringify(response), { headers });
}